package com.example.accessingdatamysql;
import org.springframework.data.repository.CrudRepository;

public interface ProductInFoRepository extends CrudRepository<ProductInFo, Integer> {

	ProductInFo findByCode(String code);

	ProductInFo findById(long id);
}
