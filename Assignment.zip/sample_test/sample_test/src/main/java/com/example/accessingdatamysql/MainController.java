package com.example.accessingdatamysql;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(path = "/sample")
public class MainController {

	@Autowired
	private ProductInFoRepository productInFoRepository;

	private final CsvExportService csvExportService;

	@PostMapping(path = "/createOrUpdate")
	public @ResponseBody String addNewProduct(@RequestParam String source, @RequestParam String codeListCode,
			@RequestParam String code, @RequestParam String displayValue, @RequestParam String longDescription,
			@RequestParam String fromDate, @RequestParam String toDate, @RequestParam String sortingPriority) {

		ProductInFo createOrUpdate = productInFoRepository.findByCode(code);
		if (null == createOrUpdate) {
			ProductInFo productInFo = new ProductInFo();
			productInFo.setCode(code);
			productInFo.setSource(source);
			productInFo.setCodeListCode(codeListCode);
			productInFo.setDisplayValue(displayValue);
			productInFo.setFromDate(fromDate);
			productInFo.setLongDescription(longDescription);
			productInFo.setSortingPriority(sortingPriority);
			productInFo.setToDate(toDate);
			productInFoRepository.save(productInFo);
			return "created";
		} else {
			createOrUpdate.setCode(code);
			createOrUpdate.setSource(source);
			createOrUpdate.setCodeListCode(codeListCode);
			createOrUpdate.setDisplayValue(displayValue);
			createOrUpdate.setFromDate(fromDate);
			createOrUpdate.setLongDescription(longDescription);
			createOrUpdate.setSortingPriority(sortingPriority);
			createOrUpdate.setToDate(toDate);
			productInFoRepository.save(createOrUpdate);
			return "updated";
		}
	}

	@GetMapping(path = "/fetchAll")
	public @ResponseBody Iterable<ProductInFo> getAllProductInfo() {
		return productInFoRepository.findAll();
	}

	public MainController(CsvExportService csvExportService) {
		this.csvExportService = csvExportService;
	}

	@GetMapping(path = "/findByCode")
	public @ResponseBody ProductInFo getProductInfoByCode(@RequestParam String code) {
		return productInFoRepository.findByCode(code);
	}

	@GetMapping(path = "/deleteAll")
	public @ResponseBody String deleteAll() {
		productInFoRepository.deleteAll();
		return "deleted all the records";
	}

	@GetMapping(path = "/exportProductInfoInCsv")
	public void getAllProductInfoInCsv(HttpServletResponse servletResponse) throws IOException {
		servletResponse.setContentType("text/csv");
		servletResponse.addHeader("Content-Disposition", "attachment; filename=\"ProductInfoInCsv.csv\"");
		csvExportService.writeProductInfoInCsvToCsv(servletResponse.getWriter());
	}
}