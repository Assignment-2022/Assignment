package com.example.accessingdatamysql;

import java.io.IOException;
import java.io.Writer;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.springframework.stereotype.Service;

@Service
public class CsvExportService {
	    private final ProductInFoRepository productInFoRepository;

	    public CsvExportService(ProductInFoRepository productInFoRepository) {
	        this.productInFoRepository = productInFoRepository;
	    }
	    
	    public void writeProductInfoInCsvToCsv(Writer writer) {

	        Iterable<ProductInFo> productInFos = productInFoRepository.findAll();
	        try (CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT)) {
	        	csvPrinter.printRecord("Source","CodeListCode", "Code", "DisplayValue", "LongDescription","FromDate","ToDate","SortingPriority");
	            for (ProductInFo productInFo : productInFos) {
	                csvPrinter.printRecord(productInFo.getSource(), productInFo.getCodeListCode(), productInFo.getCode(), productInFo.getDisplayValue(), productInFo.getLongDescription(),productInFo.getFromDate(),productInFo.getToDate(),productInFo.getSortingPriority());
	            }
	        } catch (IOException e) {
	            System.out.println(e.getMessage());
	        }
	    }
}
